package day02;

public class Samsmark {

	public static void main(String[] args) {
		double phyMarks = 95; //Sam's Physics's marks
		double mathMarks = 94;
		double chemMarks = 96;
		System.out.print("Sam's average mark in PCM is " +((phyMarks+mathMarks+chemMarks)/3));
	}

}
