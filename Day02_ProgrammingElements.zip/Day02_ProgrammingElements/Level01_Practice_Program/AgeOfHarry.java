package day02;

public class AgeOfHarry {

	public static void main(String[] args) {
		int birthYear = 2000; // Harrry's Birth Year
		int currentYear = 2024; // Current Year
		System.out.print("Harry's age in "+(currentYear)+" is "+(currentYear-birthYear)); //output
	}

}
